//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.util.List;

/*This class creates a food source
* sets the objective function
* calculated the fitness function
* returns the foodsource
* prints the food source
* returns the total wastage in the food source
* */
public class FoodSource
{
    private int totalBins;
    private List<List<Integer>> foodSource;
    private int maxBinCapacity;

    /*This is the constructor*/
    public FoodSource(List<List<Integer>> foodSource, int maxBinCapacity)
    {
        this.foodSource = foodSource;
        this.maxBinCapacity = maxBinCapacity;
        this.totalBins = foodSource.size();
    }

    //The objective function is the total number of bins
    int getObjectiveFun()
    {
        return totalBins;
    }

    List<List<Integer>> getFoodSource()
    {
        return foodSource;
    }

    /*This method returns the total wastage
    * */
    public int getTotalWastage()
    {
        int wastage = 0;

        for (int i = 0; i < foodSource.size(); i++)
        {
            Bin b = new Bin(foodSource.get(i), maxBinCapacity);
            wastage += b.getBinWastage();
        }
        return wastage;
    }

    /**
     * This part calculates the fitness function
     */
    public float getFitness()
    {
        float fitness = (float)1 / (1 + totalBins);
        return fitness;
    }


    /**This method prints the total number of bins,
     * Total wastage
     * and the items in each bin
     * **/

    public void printFoodSource()
    {
        System.out.println("Total number of bins: " + foodSource.size());
        System.out.println("Wastage: " + getTotalWastage());
        for (int i = 0; i < foodSource.size(); i++)
        {
            System.out.println("Items in Bin " + (i + 1) + ": " + foodSource.get(i).toString());
        }
        System.out.print("\n");

    }
}
