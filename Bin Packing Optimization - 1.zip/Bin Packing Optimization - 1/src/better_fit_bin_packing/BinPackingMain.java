//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

public class BinPackingMain
{
    /**This is the main class
     * Prints the results of the Artificial Bee Colony
     * */
    public static void main(String[] args)
    {

        int capacity = 0;
        int numItems = 0;
        int[] items = null;
        int counter = 0;
        int swarmSize = 0;
        int noCycles = 0;

        Scanner scan = new Scanner(System.in);
        try
        {
            File file = new File("resources/N4C3W4_R.BPP");
            Scanner sc = new Scanner(file);
            numItems = sc.nextInt();
            capacity = sc.nextInt();
            items = new int[numItems];

            while (sc.hasNextInt())
            {
                int i = sc.nextInt();
                items[counter] = i;
                counter++;

            }
            sc.close();


        }
        catch (Exception e)
        {
            System.out.println("File not available");
        }


        System.out.print("Enter swarm size: ");
        swarmSize = scan.nextInt();

        System.out.print("Enter number of cycles: ");
        noCycles = scan.nextInt();

        ArtificialBeeColony abc = new ArtificialBeeColony(swarmSize, noCycles, capacity, items);
        abc.performBeeColony();




    }

}
