//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.util.ArrayList;
import java.util.List;

//This class does the packing, Better Fit algorithm is used.
public class Packing
{

    private int maxBinCapacity;
    private int[] items;
    List<List<Integer>> bins = new ArrayList<List<Integer>>();

    public Packing(int maxBinCapacity, int[] items)
    {
        this.maxBinCapacity = maxBinCapacity;
        this.items = items;
    }

    public int getMaxBinCapacity()
    {
        return maxBinCapacity;
    }

    public int[] getItems()
    {
        return items;
    }

    public void setMaxBinCapacity(int maxBinCapacity)
    {
        this.maxBinCapacity = maxBinCapacity;
    }

    public void setItems(int[] items)
    {
        this.items = items;
    }

    public void setBins(List<List<Integer>> bins){
        this.bins = bins;
    }


    public void pack()
    {

        for (int item : items)
        {
            betterFit(item);
        }
    }

    public void betterFit(final int nextObject)
    {
        int theObject = nextObject;


        for (int i = 0; i < bins.size(); i++)
        {
            List<Integer> bin = bins.get(i);

            //Put this packet in this bin if this packet is the better fit
            int index = isBetterFit(bin, theObject);
            if (index != -1)
            {
                int tmp = theObject;
                theObject = bin.get(index);
                bin.remove(index);
                bin.add(tmp);
            }
            //return the object to be removed
        }

        bestFit(theObject);

    }

    /**
     * this part inserts the first item on the list to be packed or
     * the last replaced object is then packed with the best-fit heuristic (Checked)
     **/
    public void bestFit(int newObject)
    {
        int itemAdded = 0;

        if (bins.size() > 0)
        {
            for (int i = 0; i < bins.size(); i++)
            {
                Bin bin = new Bin(bins.get(i), maxBinCapacity);
                if (bin.itemAdded(newObject) == 1)
                {
                    bins.get(i).add(newObject);
                    itemAdded = 1;

                    break;
                }
            }
        }

        if (itemAdded == 0)
        {
            List<Integer> newBin = new ArrayList<Integer>();
            if (newObject < maxBinCapacity)
            {
                newBin.add(newObject);
                bins.add(newBin);
                //System.out.println("Item added 2nd if, the Bin number is : " + Bins.size());

            }
            else
            {
                System.out.println("Error !, Item size greater than bigger bin size");
            }
        }
    }


    /**
     * Checks if this packet fits better in this bin
     *
     * @param bin    the bin to check
     * @param packet the packet to fit in the bin
     * @return the index of the packet to be removed to fit the
     * given packet, return -1 if the packet is not a better fit
     * in this bin
     */
    private int isBetterFit(final List<Integer> bin, final int packet)
    {
        Bin b = new Bin(bin, maxBinCapacity);
        int binSize = b.getCurrentCapacity();

        for (int index = 0; index < bin.size(); index++)
        {
            int newSize = 0;

            for (int index2 = 0; index2 < bin.size(); index2++)
            {
                if (index == index2)
                {
                    newSize += packet;
                }
                else
                {
                    newSize += bin.get(index2);
                }
            }

            if ((binSize < newSize) && (newSize <= maxBinCapacity)) return index;
        }

        return -1;
    }
    /* Returns the bins
    * */
    public List<List<Integer>> getBins()
    {
        return bins;
    }

    public int getTotalBins()
    {
        return bins.size();
    }

    /*Prints the packed bins*/
    public void printPackedBins()
    {
        System.out.println("Number of bins is: " + bins.size());
        int wastage = 0;
        Bin bin;
        for (int i = 0; i < bins.size(); i++)
        {
            System.out.println("Items in Bin " + (i + 1) + ": " + bins.get(i).toString());
            bin = new Bin(bins.get(i),maxBinCapacity);
            wastage += bin.getBinWastage();
        }
        System.out.print("Wastage: " + wastage);
    }

}
