//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**This class creates a new food source*/
public class NewFoodSource
{
    private List<List<Integer>> currFoodSource;
    int maxBinCapacity;
    int popSize;
    int [] items;

    public NewFoodSource(List<List<Integer>> currFoodSource, int maxBinCapacity, int popSize , int [] items){
        this.currFoodSource = currFoodSource;
        this.maxBinCapacity = maxBinCapacity;
        this.popSize = popSize;
        this.items = items;
    }

    /**Removes bins in the food source to repack
     * food sources are selected at random
     * in order to repack*/
    public int [] removedBinsList(){

        int noBinsToRepack = getNumberBinsToRepack();
        List<Integer> itemsRepackList = new ArrayList<Integer>();
        int [] arrItemsRepackList;
        List<List<Integer>> removedBins = new ArrayList<List<Integer>>();
        Random rand = new Random();

        for(int i = 0; i < noBinsToRepack; i++ ){
            int selBin = rand.nextInt(currFoodSource.size());
            removedBins.add(currFoodSource.remove(selBin));
        }

        for(int index = 0; index < removedBins.size();index++){
            List<Integer> bin = removedBins.get(index);
            for(int index1 = 0; index1 < bin.size(); index1++){
                itemsRepackList.add(bin.get(index1));
            }
        }

        arrItemsRepackList = new int[itemsRepackList.size()];
        for(int index = 0; index < itemsRepackList.size(); index++){
            arrItemsRepackList[index] = itemsRepackList.get(index);
        }
        return arrItemsRepackList;
    }

    /**Repacks the removed bins into the same food source they were removed
     * returns the new food source
     * */
    public List<List<Integer>> getNewFoodSource(){
        int [] itemsRepack = removedBinsList();
        Packing pack = new Packing(maxBinCapacity, itemsRepack);
        pack.setBins(currFoodSource);
        pack.pack();
        List<List<Integer>> newFoodSource = pack.getBins();
        return newFoodSource;
    }

    /*returns the number of bins to be repacked*/
    public int getNumberBinsToRepack(){

        int [] newItems = new int [items.length/2];
        int noBins;
        for(int i = 0; i < items.length/2; i++){
            newItems[i]  = items[i];
        }
        Packing pack = new Packing(maxBinCapacity, newItems);
        noBins = pack.getTotalBins();
        return noBins;
    }



}
