//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.util.Random;
/*
* This class randomize the position of items in the array
* */
public class Randomize
{
    int []items;
    int randIndex1;
    int randIndex2;
    Random rand = new Random();
    int counter = 0;
    /**This constructor which takes in an array of items*/
    public Randomize(int [] items){
        this.items = items;
    }

    /*Creates a randomized list*/
    int [] RandomizedList(){

        while(counter < items.length){
            randIndex1 = rand.nextInt(items.length);
            randIndex2 = rand.nextInt(items.length);
            if(randIndex1 != randIndex2){
                int temp = items[randIndex1];
                items[randIndex1] = items[randIndex2];
                items[randIndex2] = temp;
                counter++;
            }
        }
        return items;
    }

}
