//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ArtificialBeeColony
{
    private int swarmSize = 0;
    private int noCycles = 0;
    private int maxBinCapacity;
    private int wastage = 0;
    private int popSize;
    private int limit;
    private int[] items;
    private int[] objFun;
    private List<Float> fitFun = new ArrayList<Float>();
    private FoodSource[] arrayPop;
    private int[] trialVec;
    private FoodSource bestFoodSource;

    public ArtificialBeeColony(int swarmSize, int noCycles, int maxBinCapacity, int[] items)
    {
        this.swarmSize = swarmSize;
        this.noCycles = noCycles;
        this.maxBinCapacity = maxBinCapacity;
        this.popSize = swarmSize / 2;
        this.items = items;
        arrayPop = new FoodSource[popSize];
        objFun = new int[popSize];
        this.trialVec = new int[popSize];
        limit = (swarmSize/2)*(popSize/2);

    }
    public int getMaxFitIndex(){
        float max = fitFun.get(0);
        int fitIndex = 0;
        for (int i = 1; i < fitFun.size(); i++)
        {
            if (fitFun.get(i) > max)
            {
                max = fitFun.get(i);
                fitIndex = i;
            }
        }
        return fitIndex;
    }

    private void setBestFoodSource(){
        int bIndex = getMaxFitIndex();
        bestFoodSource = arrayPop[bIndex];
    }
    /*This method generates the initial population by
     *First randomize the items
     * Then packing the items using the better fit algorithm
     * The create a new food source
     * Store the fitness function and objective function
     * Initialize the trial vector to zero**/
    public void initPop()
    {
        for (int i = 0; i < popSize; i++)
        {
            Randomize rand = new Randomize(items);
            int[] randomizedItems = rand.RandomizedList();
            Packing p = new Packing(maxBinCapacity, randomizedItems);
            p.pack();
            FoodSource fs = new FoodSource(p.getBins(), maxBinCapacity);
            arrayPop[i] = fs;
            objFun[i] = fs.getObjectiveFun();
            fitFun.add(fs.getFitness());
            trialVec[i] = 0;
        }
        setBestFoodSource();
    }
    /*Employeed bee phase tries to identify a better food source than the one associated with it
    * Generate a new solution accept the new food source if its better than the current one*/
    public void employedBee()
    {
        for (int i = 0; i < popSize; i++)
        {
            FoodSource currFoodSource = arrayPop[i];
            NewFoodSource nfs = new NewFoodSource(currFoodSource.getFoodSource(), maxBinCapacity, popSize, items);
            FoodSource newFoodSource = new FoodSource(nfs.getNewFoodSource(), maxBinCapacity);
            currFoodSource.printFoodSource();

            if (currFoodSource.getFitness() < newFoodSource.getFitness())
            {
                System.out.println("New optimum solution");
                newFoodSource.printFoodSource();
                arrayPop[i] = newFoodSource;
                objFun[i] = newFoodSource.getObjectiveFun();
                fitFun.set(i, newFoodSource.getFitness());
                trialVec[i] = 0;
            }
            else
            {
                System.out.println("Current solution");
                currFoodSource.printFoodSource();
                trialVec[i]++;
            }
        }

        setBestFoodSource();
        System.out.println("\n");
    }

    /**
     * Get the max fitness
     */
    public float getMaxFit()
    {
        float max = 0;
        for (int i = 0; i < fitFun.size(); i++)
        {
            if (fitFun.get(i) > max)
            {
                max = fitFun.get(i);
            }
        }
        return max;
    }
    public float [] getProbs()
    {
        float max = getMaxFit();
        float calProb;
        float [] probs = new float[fitFun.size()];
        for (int i = 0; i < fitFun.size(); i++)
        {
            calProb = (float) (0.9 * (fitFun.get(i) / max) + 0.1);
            probs[i] =  calProb;
        }
        return probs;
    }

    public float getMaxValue(float[] probsArray){
        float max = 0;

        for(int row = 0; row < probsArray.length; row++){
            if(probsArray[row] > max){
                max = probsArray[row];
            }
        }
        return max;
    }
    /*Onlooker bee phase select a food source with a probability related to the nectar amount
    * Generate a new solution
    * Select the new solution if its better than the old*/
    public void onLookerBee()
    {
        Random rand = new Random();
        float rNum;
        int rPop;
        float [] probs = getProbs();
        float probMAx = getMaxValue(probs);
        int count = 0;
        int bee = 0;

        while(bee < probs.length)
        {
            rNum = (float) (Math.random()*(probMAx));
            if (count == probs.length-1)
            {
                count = 0;
            }
            if (rNum < probs[count])
            {
                bee++;
                rPop = (int)(Math.random()*arrayPop.length-1);
                FoodSource currFoodSource = arrayPop[rPop];

                //this part is repacking the current food sources
                NewFoodSource nfs = new NewFoodSource(currFoodSource.getFoodSource(), maxBinCapacity, popSize, items);
                FoodSource newFoodSource = new FoodSource(nfs.getNewFoodSource(), maxBinCapacity);

                if (currFoodSource.getFitness() < newFoodSource.getFitness())
                {
                    newFoodSource.printFoodSource();

                    arrayPop[rPop] = newFoodSource;
                    objFun[rPop] = newFoodSource.getObjectiveFun();
                    fitFun.set(rPop, newFoodSource.getFitness());
                    trialVec[rPop] = 0;
                }
                else if(currFoodSource.getFitness() > newFoodSource.getFitness())
                {
                    trialVec[rPop]++;
                }
            }
            count++;
        }

        setBestFoodSource();

        System.out.println("\n");
    }

    /*Discards the food source who's trial vector has exceeded the limit
    * and replaces this food source with a new randomly selected food source*/
    public void ScoutBeePhase()
    {
        setBestFoodSource();
        int fsDiscard = 0;
        int indexDiscard = -1;
        for(int i = 0; i < trialVec.length; i++){
            if(trialVec[i] > fsDiscard){
               fsDiscard = trialVec[i];
               indexDiscard = i;
            }
        }
        if(fsDiscard > limit){

            System.out.println("Removed Index in Scout Phase");
            arrayPop[indexDiscard].printFoodSource();

            Randomize rand = new Randomize(items);
            int[] randomizedItems = rand.RandomizedList();
            Packing p = new Packing(maxBinCapacity, randomizedItems);
            p.pack();
            FoodSource fs = new FoodSource(p.getBins(), maxBinCapacity);
            arrayPop[indexDiscard] = fs;
            objFun[indexDiscard] = fs.getObjectiveFun();
            fitFun.add(fs.getFitness());
            trialVec[indexDiscard] = 0;
        }
        System.out.println("\n");
    }


    public FoodSource getBestfoodSouce(){
        return bestFoodSource;
    }

    /**
     * Prints the population objective functions
     */
    public void printPopObjFun()
    {
        for (int i = 0; i < fitFun.size(); i++)
        {
            System.out.println("The Fitness function of " + (i + 1) + ": " + fitFun.get(i));
        }
    }
    /**
     * creates the initial population,
     * first randomize the items in the list
     * then pack the items using better fit algorithm
     * then add the new packed items to the population
     * objective function add to an array
     * calculate the fitness function and to an array
     */
    public void performBeeColony(){
        long startTime = System.currentTimeMillis();
        initPop();
        for(int i = 0; i < noCycles; i++){
            employedBee();
            onLookerBee();
            ScoutBeePhase();
        }
        System.out.println("This is the optimum solution");
        getBestfoodSouce().printFoodSource();
        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        System.out.println("Time taken in milliseconds: " + elapsedTime + "ms");


    }

}
