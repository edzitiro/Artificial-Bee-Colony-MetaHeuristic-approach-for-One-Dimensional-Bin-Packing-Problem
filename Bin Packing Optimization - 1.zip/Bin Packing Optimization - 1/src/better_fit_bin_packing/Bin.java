//216023315 Esther M Dzitiro, COMP719 Mini Project
package better_fit_bin_packing;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a bin and does all the operation that have to be done within the bin
 */
public class Bin
{
    ArrayList<Integer> packet;
    int maxBinCapacity;
    List<Integer> bin = new ArrayList<Integer>();

    public Bin(List<Integer> bin, int maxBinCapacity)
    {
        this.maxBinCapacity = maxBinCapacity;
        this.bin = bin;
    }

    /**
     * Returns the bin current capacity
     */
    public int getCurrentCapacity()
    {
        int totalValue = 0;
        for (Integer binItem : bin)
        {
            totalValue += binItem;
        }
        return totalValue;
    }

    /**
     * Checks if the new item is going to fit into the bin
     */
    public int itemAdded(int packet)
    {
        int currCapacity = getCurrentCapacity();
        if ((currCapacity + packet) <= maxBinCapacity)
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }

    public void printBinContent()
    {
        System.out.print(bin.toString());
    }

    public int getIndex(int index)
    {
        return bin.get(index);
    }

    public int getBinWastage()
    {
        return maxBinCapacity - getCurrentCapacity();
    }

}
